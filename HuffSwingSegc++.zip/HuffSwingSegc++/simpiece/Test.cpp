#include"HuffSwingSeg.hpp"

int main() {
    
    HuffSwingSeg t;
    t.testHuffSwingSeg();

    return 0;
}
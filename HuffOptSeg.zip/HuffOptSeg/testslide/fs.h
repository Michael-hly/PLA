#ifndef FS_H
#define FS_H

class FS {
public:
	double lowerBound;
	double upperBound;

	FS();
	FS(const FS & inObj);
};

#endif 

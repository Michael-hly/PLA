#include <iostream>
#include <fstream>
#include <time.h>
#include <cmath>
#include <algorithm>
#include <functional>
#include <iterator>
#include <deque>
#include <vector>
#include <list>
#include <stdlib.h>


using namespace std;
#define NULL 0
#define INFINITY 99999
#define MINIMUM 0.000001
#define alfa 0.025
#define beta 0.025
#define derror 0.000001
